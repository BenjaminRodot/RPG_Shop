<template>
  <div>
    <div>

      <!-- EXO 4.5 : affiche 2 x [label+champ de saisies] + bouton pour pouvoir assigner les items achetés -->

      <label>Bought Items Index</label>
      <input v-model="idxItemBought">
      <br>
      <label>Slot Items Index</label>
      <input v-model="idxSlotAssign">
      <br>
      <button @click="assign(idxItemBought,idxSlotAssign)">Assign</button>

    </div>

    <div style="height:20px"></div>

    <div>

      <!-- EXO 4.7 : affiche label+champ de saisie + bouton pour pouvoir acheter un item de la boutique -->
      <label>Items Index</label>
      <input v-model="idxItemBuy">
      <br>
      <button @click="buy(idxItemBuy)">Buy</button>
    </div>

    <div style="height:20px"></div>

    <div>

      <!-- EXO 4.9 : affiche label+champ de saisie + bouton pour pouvoir commander un item de la boutique -->

      <label>Items Index</label>
      <input v-model="idxItemOrder">
      <br>
      <button @click="order(idxItemOrder)">Order</button>
    </div>

    <div style="height:20px"></div>

    <div>

      <!-- EXO 4.11 : affiche 2 x [label+champ de saisies] + bouton pour pouvoir vendre un item assigné à un slot -->

      <label>Sell Items Index</label>
      <input v-model="idxItemSell">
      <br>
      <label>Sell Slot Index</label>
      <input v-model="idxSlotSell">
      <br>
      <button @click="sell(idxItemSell,idxSlotSell)">Sell</button>

    </div>
  </div>
</template>

<script>
import {players} from "../model";

export default {
  name: "PersoOps",
  data: () => {
    return {
      players, // la liste des persos (permet d'observer la variable externe players, importée depuis model.js)
      idxItemBuy:1, // la valeur du champ de saisie pour acheter un item
      idxItemOrder:1, // la valeur du champ de saisie pour commander un item
      idxItemBought:1, // la valeur du champ de saisie "index item" pour assigner un item
      idxSlotAssign:1, // la valeur du champ de saisie "index slot" pour assigner un item
      idxItemSell:1, // la valeur du champ de saisie "index item" pour vendre un item
      idxSlotSell:1, // la valeur du champ de saisie "index slot" pour vendre un item
    }
  },
  methods: {
    assign(idxItemBought,idxSlotAssign) {
      if(this.currentPlayer.boughtItems.length===0){
        alert("You didn't buy any item, hurry up !!!");
        return;
      }

      if(idxItemBought<0 || idxItemBought>this.currentPlayer.boughtItems.length-1){
        alert("Le numero de l'objet achete doit être compris entre 0 et "+this.currentPlayer.boughtItems.length-1);
        return;
      }

      if(idxSlotAssign<0 || idxSlotAssign>4){
        alert("Le numero de l'objet achete doit être compris entre 0 et 4");
        return;
      }
      let message = this.currentPlayer.assign(idxItemBought,idxSlotAssign);

      if(message!=="")
        alert(message);
    },
    buy(idxItemBuy) {
      console.log(this.currentShop)
      idxItemBuy-=1;
      if ((isNaN(idxItemBuy)) || (idxItemBuy <0)||(idxItemBuy >= this.currentShop.itemStock)) {
        alert("Invalid item number");
        return;
      }
      let item = this.currentShop.itemStock[idxItemBuy];
      console.log(item.name)
      let ret = this.currentPlayer.buy(item);
      if (ret !== "") {
        alert(ret);
      }
    },
    async order(idxItemOrder) {

      idxItemOrder -= 1;
      if ((isNaN(idxItemOrder)) || (idxItemOrder < 0) || (idxItemOrder >= this.currentShop.itemOrder.length)) {
        alert("invalid item index");
        return;
      }

      setTimeout(() => { this.currentShop.order(idxItemOrder)}, 1000);
    },
    sell(idxItemSell,idxSlotSell) {

      if ((isNaN(idxSlotSell)) || (idxSlotSell < 0) || (idxSlotSell >= this.currentPlayer.slots.length)) {
        alert("invalid slot index");
        return;
      }
      if (this.currentPlayer.slots[idxSlotSell].items.length === 0) {
        alert("no item to sell for the slot");
        return;
      }
      if ((isNaN(idxItemSell)) || (idxItemSell < 0) || (idxItemSell >= this.currentPlayer.slots[idxSlotSell].items.length)) {
        alert("invalid item index");
        return;
      }
      let item = this.currentPlayer.slots[idxSlotSell].items[idxItemSell];
      let amount = this.currentShop.estimate(item);
      if (amount === -1) {
        alert("cannot sell this type of item in this shop");
        return
      }
      let ans = confirm("sell "+item.name+" for "+amount+"po ?");
      if (ans) {
        this.currentShop.buy(item);
        this.currentPlayer.sell(idxSlotSell,idxItemSell,amount);
      }
    },
  },
  props:{
    currentPlayer:Object,
    currentShop:Object,
    currentTown : Object,
  }
}
</script>

<style scoped>

</style>