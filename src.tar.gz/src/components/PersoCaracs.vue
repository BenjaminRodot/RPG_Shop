<template>
  <div>
    <p>{{currentPlayer.name}} - lvl {{currentPlayer.level}} -  {{currentPlayer.life}} hp</p>
    <label>Gold</label>
    <input readonly :value="currentPlayer.gold">
  </div>
</template>

<script>

export default {
  name: "PersoCaracs",
  props:{
    currentPlayer:Object
  }
}
</script>

<style scoped>

</style>