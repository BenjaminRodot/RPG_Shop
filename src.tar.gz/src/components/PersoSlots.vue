<template>
  <div>
    <table border="1">
      <tr v-for="(slot,index) in currentPlayer.slots" v-bind:key="index">
        <td>{{slot.name}}</td>
        <td v-for="(item,index) in slot.items" v-bind:key="index">
          {{index}} - {{item.name}}
        </td>
      </tr>
    </table>
    <div>
      <label>Bought Items</label>
      <input readonly :value="boughtItems">
    </div>
  </div>

</template>

<script>

export default {
  name: "PersoSlots",
  computed: {
    boughtItems() {
      let txt = ""
      this.currentPlayer.boughtItems.forEach((item,index) =>{
        txt+="[ "+index+" ] - "+item.name
      })
      return txt;
    },
  },
  props:{
    currentPlayer:Object
  }
}
</script>

<style scoped>

</style>